# PDF Toolkit — Get Your APK (Phone Only, No Laptop Needed)

## Step 1 — Upload to GitHub (from your phone)

1. Go to **github.com** in Chrome
2. Sign up / log in (free)
3. Tap **"New repository"**
4. Name it: `pdf-toolkit`
5. Set to **Public**
6. Tap **"Create repository"**
7. Tap **"uploading an existing file"**
8. Upload ALL files from this zip:
   - `index.html`
   - `vite.config.js`
   - `package.json`
   - `capacitor.config.json`
   - `codemagic.yaml`
   - `src/App.jsx`
   - `src/main.jsx`
   - `public/manifest.json`
9. Tap **"Commit changes"** ✅

---

## Step 2 — Build APK on Codemagic (free)

1. Go to **codemagic.io** in Chrome
2. Sign up with your GitHub account
3. Tap **"Add application"**
4. Select your `pdf-toolkit` repo
5. Choose **"Other"** as project type
6. Codemagic detects `codemagic.yaml` automatically
7. Tap **"Start build"**
8. Wait ~10 minutes ☁️
9. Download **app-debug.apk** to your phone ✅

> Codemagic will also email you the APK link!
> Enter your email in codemagic.yaml before building.

---

## Step 3 — Test on your phone

1. Open the downloaded APK
2. Android will ask to allow install from unknown sources → Allow
3. App installs and runs ✅

---

## Step 4 — Publish to Play Store

1. Go to **play.google.com/console**
2. Pay one-time **$25** developer fee
3. Tap **"Create app"**
4. Upload your APK
5. Fill in app details + screenshots
6. Submit for review → approved in 3–7 days 🎉

---

## Features in your app:
- Merge PDFs
- Split PDF
- Reorder pages
- Rotate pages
- Compress PDF
- Add watermark
- Add page numbers
- Images → PDF
- PDF → Images
- Word → PDF
- PDF → Word
- PPT → PDF
- PDF → PPT
- LaTeX → PDF
- PDF → LaTeX (editable)
- Edit text visually (tap on PDF)
- Password protect PDF
- Unlock PDF
